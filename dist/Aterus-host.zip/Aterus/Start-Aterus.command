#!/bin/zsh
set -eu
cd "$(dirname "$0")"
exec python3 aterus.py --workspace "$PWD" --data-dir "$PWD/.aterus-data"
