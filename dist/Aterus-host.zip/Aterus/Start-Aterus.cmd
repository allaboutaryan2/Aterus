@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" aterus.py --workspace "%CD%" --data-dir "%LOCALAPPDATA%\Aterus"
) else (
  py -3 aterus.py --workspace "%CD%" --data-dir "%LOCALAPPDATA%\Aterus"
)
if errorlevel 1 pause
